$(function() {
    $('#cart-form').on('submit', function() {
        alert("Yor order request has been submitted. Please wait until the request is approved.");
    });
});